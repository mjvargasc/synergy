/* Pure domain transitions. No timers, DOM or network dependencies. */
(function(root){
'use strict';
const stations=[
 {id:1,name:'Malecón Escénico',address:'Sector Malecón, Manta',distance:1.4,power:120,free:1,total:2,x:48,y:38},
 {id:2,name:'Mall del Pacífico',address:'Sector Barbasquillo, Manta',distance:0.8,power:120,free:2,total:2,x:27,y:60},
 {id:3,name:'ULEAM Campus Manta',address:'Sector universitario, Manta',distance:2.1,power:120,free:0,total:2,x:47,y:77},
 {id:4,name:'Parque Central',address:'Sector Centro, Manta',distance:2.6,power:120,free:2,total:2,x:66,y:53},
 {id:5,name:'Aeropuerto Eloy Alfaro',address:'Sector aeropuerto, Manta',distance:4.3,power:90,free:1,total:2,x:81,y:25}
];
const initial=()=>({version:1,entered:false,user:{name:'Gino',vehicle:'BYD Dolphin',plate:'DEMO-001'},battery:62,balance:34.5,active:null,history:[],transactions:[{id:'initial',name:'Saldo inicial de demostración',amount:34.5,date:'Inicio de la demo'}],home:[],theme:'light',seq:0});
const assert=(ok,message)=>{if(!ok)throw Error(message)};
function transact(s,id,name,amount){if(s.transactions.some(t=>t.id===id))return;assert(s.balance+amount>=0,'Saldo insuficiente. Recarga tu billetera de demostración.');s.balance=Math.round((s.balance+amount)*100)/100;s.transactions.unshift({id,name,amount,date:new Date().toLocaleString('es-EC')});}
function finish(s,stopped=false){const a=s.active;if(!a)return;transact(s,a.id,a.kind==='station'?'Carga · '+a.name:'Synergy Mobile',-a.price);s.battery=a.battery;s.history.unshift({...a,status:stopped?'Carga detenida':a.kind==='station'?'Carga finalizada':'Servicio completado',date:new Date().toLocaleString('es-EC')});s.active=null;}
function transition(s,action,p={}){
 switch(action){
 case 'enter':s.entered=true;break;
 case 'reserve':{assert(!s.active,'Ya tienes un servicio activo. Finalízalo o cancélalo antes de continuar.');const st=stations.find(x=>x.id===p.id);assert(st&&st.free>0,'Esta estación está ocupada. Selecciona otra estación.');assert(s.balance>=8,'Saldo insuficiente. Necesitas USD 8,00.');s.active={id:'service-'+(++s.seq),kind:'station',stationId:st.id,name:st.name,address:st.address,vehicle:s.user.vehicle,price:8,status:'reserved',start:s.battery,battery:s.battery,target:Math.min(100,Math.max(80,s.battery+5)),energy:0,minutes:0};break;}
 case 'start':assert(s.active?.kind==='station'&&s.active.status==='reserved','No hay una reserva pendiente.');s.active.status='charging';break;
 case 'advance':{const a=s.active;assert(a&&a.status==='charging','No hay una carga en curso.');a.battery=Math.min(a.target,a.battery+10);a.minutes+=10;a.energy=Number(((a.battery-a.start)*55.4/100).toFixed(2));s.battery=a.battery;if(a.battery===a.target)finish(s);break;}
 case 'stop':assert(s.active?.status==='charging'&&s.active.kind==='station','No hay una carga que detener.');finish(s,true);break;
 case 'mobile':assert(!s.active,'Ya tienes un servicio activo. Finalízalo o cancélalo antes de continuar.');assert(s.balance>=15,'Saldo insuficiente. Necesitas USD 15,00.');assert(typeof p.address==='string'&&p.address.trim().length>=10,'Escribe una dirección de al menos 10 caracteres, con calle y referencia.');assert(!p.scheduled||(Number.isFinite(Date.parse(p.scheduled))&&Date.parse(p.scheduled)>Date.now()),'Elige una fecha y hora futura.');s.active={id:'service-'+(++s.seq),kind:'mobile',name:'Synergy Mobile',address:p.address.trim(),scheduled:p.scheduled||null,clockStarted:!p.scheduled,vehicle:s.user.vehicle,price:15,status:'confirmed',step:0,start:s.battery,battery:s.battery,energy:0,minutes:0};break;
 case 'scheduleStart':assert(s.active?.kind==='mobile'&&s.active.scheduled&&!s.active.clockStarted,'La fecha simulada ya fue alcanzada.');s.active.clockStarted=true;break;
 case 'mobileNext':{const a=s.active;assert(a?.kind==='mobile','No hay una solicitud móvil.');assert(a.clockStarted,'Avanza primero a la fecha programada con el reloj de demostración.');a.step++;a.status=['confirmed','assigned','enroute','charging','completed'][a.step];if(a.step===4){a.battery=Math.min(100,a.start+18);a.energy=Number(((a.battery-a.start)*55.4/100).toFixed(2));a.minutes=30;finish(s);}break;}
 case 'cancel':assert(s.active&&(s.active.kind==='station'?s.active.status==='reserved':s.active.step<3),'No es posible cancelar en este estado.');s.history.unshift({...s.active,status:'Cancelado',price:0,date:new Date().toLocaleString('es-EC')});s.active=null;break;
 case 'topup':assert([10,20,50].includes(p.amount),'Selecciona un importe válido.');assert(typeof p.id==='string','Operación inválida.');transact(s,p.id,'Recarga simulada',p.amount);break;
 case 'home':for(const key of ['name','sector','housing','vehicle','time'])assert(typeof p[key]==='string'&&p[key].trim().length>=2,'Completa todos los campos de la evaluación.');s.home.unshift({...p,id:'home-'+(++s.seq),status:'Evaluación solicitada',date:new Date().toLocaleString('es-EC')});break;
 case 'profile':assert(p.name.trim().length>=2&&p.vehicle.trim().length>=2&&p.plate.trim().length>=2,'Completa nombre, vehículo y matrícula demo.');assert(!s.active,'Finaliza el servicio activo antes de cambiar el vehículo.');s.user={name:p.name.trim(),vehicle:p.vehicle.trim(),plate:p.plate.trim()};break;
 case 'theme':s.theme=s.theme==='light'?'dark':'light';break;
 default:throw Error('Acción desconocida');
 }return s;
}
const api={stations,initial,transition};if(typeof module!=='undefined')module.exports=api;else root.Synergy=api;
})(typeof window!=='undefined'?window:globalThis);
