const {chromium}=require(process.env.PLAYWRIGHT_PATH||'playwright');
const assert=require('node:assert/strict');
(async()=>{
 const browser=await chromium.launch({channel:'msedge',headless:true});
 const page=await browser.newPage({viewport:{width:1200,height:900}}),errors=[];
 page.on('pageerror',e=>errors.push(e.message));
 await page.addInitScript(()=>{window.audioNotes=0;const original=AudioContext.prototype.createOscillator;AudioContext.prototype.createOscillator=function(){window.audioNotes++;return original.call(this);};});
 await page.goto('http://127.0.0.1:4173');await page.locator('[data-action="enter"]').click();await page.locator('.nav [data-page="wallet"]').click();
 const balance=()=>page.evaluate(()=>JSON.parse(localStorage.getItem('synergy-demo-v1')).balance);
 let expected=34.5;
 for(const amount of [10,20,50]){
  await page.locator(`[data-action="topup"][data-amount="${amount}"]`).click();
  await page.locator('[data-action="confirm"]').evaluate(b=>{b.click();b.click();});expected+=amount;assert.equal(await balance(),expected);
  assert.equal(await page.locator('.experience-dialog[open]').count(),1);
  assert.match(await page.locator('.received-amount').innerText(),new RegExp(String(amount)));
  if(amount===10){await page.waitForTimeout(1150);await page.screenshot({path:'verification/wallet-animation.png'});}
  await page.waitForTimeout(2150);
  if(await page.locator('.experience-dialog[open]').count())assert.match(await page.locator('#animated-balance').innerText(),new RegExp(String(Math.floor(expected))));
  await page.locator('.experience-dialog').waitFor({state:'detached'});
 }
 assert.ok(await page.evaluate(()=>audioNotes)>0);
 await page.locator('.topbar [data-action="sound"]').click();const count=await page.evaluate(()=>audioNotes);
 await page.locator('[data-action="topup"][data-amount="10"]').click();await page.locator('[data-action="confirm"]').click();await page.keyboard.press('Escape');assert.equal(await page.locator('.experience-dialog').count(),0);assert.equal(await page.evaluate(()=>audioNotes),count);
 await page.reload();assert.equal(await page.locator('.topbar [data-action="sound"]').getAttribute('aria-pressed'),'false');
 await page.locator('.nav [data-page="station"]').click();await page.locator('[data-action="reviewReserve"]').click();await page.locator('[data-action="confirm"]').click();await page.locator('[data-action="start"]').click();assert.equal(await page.locator('.charge-scene').count(),1);await page.waitForTimeout(900);await page.screenshot({path:'verification/charge-animation.png'});
 await page.setViewportSize({width:390,height:850});assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
 await page.emulateMedia({reducedMotion:'reduce'});await page.locator('.nav [data-page="wallet"]').click();await page.locator('[data-action="topup"][data-amount="20"]').click();await page.locator('[data-action="confirm"]').click();assert.equal(await page.locator('.money-cart').evaluate(el=>getComputedStyle(el).animationName),'none');await page.locator('#experience-skip').click();
 assert.deepEqual(errors,[]);await browser.close();console.log('PASS audiovisual: actual amounts, single debit/credit, animated totals, Web Audio synthesis, persisted mute, Escape/skip, reduced motion, charge scene, mobile layout; no JS errors.');
})().catch(e=>{console.error(e);process.exit(1)});
