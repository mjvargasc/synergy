/* Run with PLAYWRIGHT_PATH pointing at an installed playwright package, or npm install playwright. */
const {chromium}=require(process.env.PLAYWRIGHT_PATH||'playwright');
const assert=require('node:assert/strict'),fs=require('node:fs');
(async()=>{
const browser=await chromium.launch({channel:'msedge',headless:true});
const page=await browser.newPage({viewport:{width:1440,height:1000}}),errors=[];
page.on('pageerror',e=>errors.push(e.message));
const click=a=>page.locator(`[data-action="${a}"]`).first().click();
const nav=p=>page.locator(`.nav [data-page="${p}"]`).click();
const stored=()=>page.evaluate(()=>JSON.parse(localStorage.getItem('synergy-demo-v1')));
fs.mkdirSync('verification',{recursive:true});
await page.goto('http://127.0.0.1:4173');
await page.screenshot({path:'verification/welcome.png',fullPage:true});
await click('enter');await page.screenshot({path:'verification/desktop.png',fullPage:true});
await nav('station');await page.locator('#search').fill('zzzz');assert.equal(await page.locator('.station-item').count(),0);await click('clearFilters');
await page.locator('.station-item[data-id="3"]').click();assert.equal(await page.locator('[data-action="reviewReserve"]').isDisabled(),true);
await page.selectOption('#availability','free');assert.equal(await page.locator('.station-item').count(),4);await page.selectOption('#power','120');assert.equal(await page.locator('.station-item').count(),3);
await page.selectOption('#sort','far');assert.equal(await page.locator('.station-item').first().getAttribute('data-id'),'4');
await page.locator('.station-item[data-id="2"]').click();await page.screenshot({path:'verification/station-desktop.png',fullPage:true});
await click('reviewReserve');await click('confirm');assert.equal((await stored()).active.status,'reserved');assert.equal((await stored()).balance,34.5);
await page.reload();await page.locator('.active-banner [data-action="nav"]').click();await click('start');await click('advance');await click('advance');
assert.equal((await stored()).balance,26.5);assert.equal((await stored()).history[0].name,'Mall del Pacífico');await page.screenshot({path:'verification/receipt.png',fullPage:true});
await nav('mobile');await page.locator('[name="address"]').fill('Calle Demo 123, frente al parque');await page.selectOption('#when','scheduled');const tomorrow=new Date(Date.now()+86400000);const local=new Date(tomorrow-tomorrow.getTimezoneOffset()*60000).toISOString().slice(0,16);await page.locator('#scheduled').fill(local);await page.locator('#mobile-form button').click();await click('confirm');assert.equal((await stored()).active.clockStarted,false);await page.reload();await nav('mobile');await click('scheduleStart');await click('mobileNext');await page.screenshot({path:'verification/mobile-tracking.png',fullPage:true});await click('mobileNext');await click('mobileNext');await click('mobileNext');assert.equal((await stored()).balance,11.5);assert.equal((await stored()).battery,98);
await nav('mobile');await page.locator('[name="address"]').fill('Calle Demo 456, sector ficticio');await page.locator('#mobile-form button').click();await click('confirm');assert.match(await page.locator('#modal-error').innerText(),/Saldo insuficiente/);await click('closeModal');
await nav('wallet');await page.locator('[data-action="topup"][data-amount="20"]').click();await page.locator('[data-action="confirm"]').evaluate(b=>{b.click();b.click();});assert.equal((await stored()).balance,31.5);
await nav('mobile');await page.locator('[name="address"]').fill('Calle Demo 456, sector ficticio');await page.locator('#mobile-form button').click();await click('confirm');await click('cancel');await click('confirm');assert.equal((await stored()).balance,31.5);assert.equal((await stored()).active,null);
await nav('residential');await page.locator('[name="sector"]').fill('Barbasquillo');await page.selectOption('[name="housing"]','Casa');await page.selectOption('[name="time"]',{label:'Mañana · 08:00–12:00'});await page.locator('#home-form button').click();await click('confirm');assert.equal((await stored()).home.length,1);assert.equal((await stored()).balance,31.5);await page.screenshot({path:'verification/home-service.png',fullPage:true});
await nav('profile');await page.locator('[name="name"]').fill('<img src=x onerror=alert(1)>');await page.locator('[name="vehicle"]').fill('EV Prueba');await page.locator('#profile-form button').click();await nav('home');assert.equal(await page.locator('h1 img').count(),0);assert.match(await page.locator('h1').innerText(),/<img/);assert.match(await page.locator('.vehicle-strip').innerText(),/EV Prueba/);
await nav('profile');await click('theme');assert.equal(await page.locator('body.dark').count(),1);await click('theme');
await click('reset');await click('closeModal');assert.equal((await stored()).home.length,1);await click('reset');await click('confirm');assert.equal((await stored()).balance,34.5);assert.equal((await stored()).battery,62);assert.equal((await stored()).history.length,0);await click('enter');await click('presentation');await click('guideGo');await click('guideNext');await click('guideNext');assert.match(await page.locator('h1').innerText(),/casa/);await click('presentation');
for(const width of [390,760,1024,1440]){await page.setViewportSize({width,height:900});for(const p of ['home','station','mobile','residential','wallet','profile']){await nav(p);assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),`Overflow at ${width}, ${p}`);if(width===390&&['home','station','residential'].includes(p))await page.screenshot({path:`verification/${p}-mobile.png`,fullPage:true});}}
const context=await browser.newContext({offline:true});const offline=await context.newPage();await offline.goto('file:///'+require('node:path').resolve('index.html').replaceAll('\\','/'));await offline.locator('[data-action="enter"]').click();assert.match(await offline.locator('h1').innerText(),/Hola/);await context.close();
assert.deepEqual(errors,[]);console.log('PASS: browser flows, persistence, balance, duplicate confirmation, cancellation, forms, safe text, reset, guide, 4 responsive widths, offline file opening; no JS errors.');await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
